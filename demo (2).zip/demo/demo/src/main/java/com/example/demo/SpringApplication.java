package com.example.demo;

public class SpringApplication {

	public static void run(Class<DemoApplication> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

}
