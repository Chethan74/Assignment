import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-marketing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './marketing.component.html',
  styleUrl: './marketing.component.css',
})
export class MarketingComponent {
  marketingCards = [
    {
      image: 'images/market1.png',
      title: 'Creating Streamlined Safeguarding Processes with OneRen',
    },
    {
      image: 'images/market2.png',
      title:
        'What are your safeguarding responsibilities and how can you manage them?',
    },
    {
      image: 'images/market3.png',
      title: 'Revamping the Membership Model with Triathlon Australia',
    },
  ];
}
