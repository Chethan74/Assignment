import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './navbar/navbar.component';
import { HeroComponent } from './hero/hero.component';
import { FooterComponent } from './footer/footer.component';
import { CommunityComponent } from './community/community.component';
import { ClientsComponent } from './clients/clients.component';
import { UnlockComponent } from './unlock/unlock.component';
import { AchievementComponent } from './unlock/achievement/achievement.component';
import { MarketingComponent } from './marketing/marketing.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    NavbarComponent,
    HeroComponent,
    FooterComponent,
    CommunityComponent,
    ClientsComponent,
    UnlockComponent,
    AchievementComponent,
    MarketingComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'nexcent-app';
}
