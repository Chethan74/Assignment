import { Component } from '@angular/core';
import { AchievementComponent } from './achievement/achievement.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-unlock',
  standalone: true,
  imports: [AchievementComponent, CommonModule],
  templateUrl: './unlock.component.html',
  styleUrl: './unlock.component.css',
})
export class UnlockComponent {
  stats = [
    {
      svgPath: 'images/achievment/users.png',
      statNumber: '2,245,341',
      description: 'Members',
    },
    {
      svgPath: 'images/achievment/club.png',
      statNumber: '46,328',
      description: 'Clubs',
    },
    {
      svgPath: 'images/achievment/icon3.svg',
      statNumber: '828,867',
      description: 'Event Bookings',
    },
    {
      svgPath: 'images/achievment/icon4.svg',
      statNumber: '1,926,436',
      description: 'Payments',
    },
  ];
}
