import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-achievement',
  standalone: true,
  imports: [],
  templateUrl: './achievement.component.html',
  styleUrl: './achievement.component.css',
})
export class AchievementComponent {
  @Input() statNumber: string = '';
  @Input() description: string = '';
  @Input() svgPath: string = '';
}
