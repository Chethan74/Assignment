import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class ClientsComponent {
  clientLogos = [
    'images/clients/icon1.svg',
    'images/clients/icon2.svg',
    'images/clients/icon3.svg',
    'images/clients/icon4.svg',
    'images/clients/icon5.svg',
    'images/clients/icon6.svg',
    'images/clients/icon7.svg',
  ];
}
